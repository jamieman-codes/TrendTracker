# TrendTracker
Small python project that tracks trends from Google and Twitter. Complete with installer
